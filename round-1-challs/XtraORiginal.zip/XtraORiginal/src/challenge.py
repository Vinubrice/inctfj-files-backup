message = # Redacted :)
key = 'MasterKe' #guess the last character!

output = [ord(character) ^ ord(keyCharacter) for character,keyCharacter in zip(message,(key*6))] #why multiply the key??

print(f'Length of the message: {len(message)}\nLength of the key: {len(key)}')
print(output)