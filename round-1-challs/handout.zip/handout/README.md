# runtime 

### Description
I have this weird .py file with me, can you run it and tell me what it prints out? 

### Resources
1. [What is a .py file? How can I run it?](https://realpython.com/run-python-scripts/)
