from Crypto.Util.number import *

hidden_msg= # redacted :)

m=bytes_to_long(hidden_msg.encode())

p=getPrime(256)
q=getPrime(256)

N=p*q

e=3 # I mean it's faster right

phi=(p-1)*(q-1) 
d=pow(e,-1,phi) # redacted

c=pow(m,e,N)

with open("given.txt", "w") as f:
    f.writelines([f"ciphertext intercepted is: {c}\n",f"public exponent: {e}\n",f"the modulus: {N}"])







