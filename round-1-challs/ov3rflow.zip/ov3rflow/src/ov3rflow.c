#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/random.h>
#include <unistd.h>

char flag[100];

void init(){
    setvbuf(stdin,NULL,2,0);
    setvbuf(stdout,NULL,2,0);
    FILE *fp = fopen("flag.txt","r");
    if(fp == NULL){
        puts("[ERROR] : Maybe missing flag file");
        exit(-1);
    }
    fread(flag,100,1,fp);
}

int main(){
    char user_code[16];
    char password[16];
    char array[40];
    init();
    getrandom(password,sizeof(password),0);
    printf("[LOGIN] Enter your name : ");
    gets(array);
    printf("[LOGIN] Enter the access key : ");
    fgets(user_code,16,stdin);
    if(memcmp(password,user_code,sizeof(password) - 1) == 0){
        printf("[LOGGED IN] : Here is your flag >> ");
        printf("%s\n",flag);
        printf("[EXITING] Bye\n");
        fflush(stdout);
        sleep(3);
        exit(0);
    } else {
        printf("The Key is incorrect\nTry better\n");
        exit(-1);
    }
}