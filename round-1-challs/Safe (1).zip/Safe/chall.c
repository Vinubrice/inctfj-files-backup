#include <stdio.h>
#include <stdlib.h>

void init(){
        setvbuf(stdin, NULL, _IONBF, 0);
        setvbuf(stdout, NULL, _IONBF, 0);
}

void flagprinter(){
    FILE *file = fopen("flag.txt", "r");
    if (!file) {
        perror("You should have a flag.txt file in this directory");
        exit(0);
    }

    int ch;
    while ((ch = fgetc(file)) != EOF) {
        putchar(ch);
    }

    fclose(file);
}

int main(){
    init();

    char name[25];
    int flag = 0xdeadbeef;

    printf("The flag will only be revealed if you possess the secret code for the safe");
    printf("Enter your guess: \n");
    printf("> ");
    gets(name);

    if(flag == 0xcafebabe){
        flagprinter(); 
    }
    else{
        puts("Woops! No flag for you");
    }

    return 0;
}